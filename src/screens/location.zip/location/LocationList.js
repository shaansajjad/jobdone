import React from "react";
import TextField from "@material-ui/core/TextField";
import { makeStyles, createStyles } from "@material-ui/core";

const style = makeStyles((theme) =>
  createStyles({
    mainButton: {
      position: "relative",
    },
    addbutton: {
      position: "absolute",
      left: "0",
    },
  })
);

const LocationList = (props) => {
  const classes = style();
  return props.taskList.map((item, index) => {
    return (
      <div key={index}>
        <form onSubmit={props.submitLocation}>
          <TextField
            margin="normal"
            fullWidth
            name="location_name"
            data-id={index}
            value={item.name}
            label="Team Name"
            placeholder="E.g. City Center"
            type="text"
            onChange={props.handleChange}
            id="location_name"
            autoComplete="location-name"
          />
        </form>

        <div className={classes.mainButton}>
          {index === 0 ? (
            <button
              onClick={() => props.addNewLocation()}
              className={classes.addbutton}
            >
              <i className="fa fa-plus-circle" aria-hidden="true"></i>
              Add Location
            </button>
          ) : (
            <button onClick={() => props.delete(item)}>
              <i className="fa fa-minus" aria-hidden="true"></i>
            </button>
          )}
        </div>
      </div>
    );
  });
};
export default LocationList;
